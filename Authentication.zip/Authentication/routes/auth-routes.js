const express = require("express")
const router = express.Router()
const {registerUser, loginUser} = require("../controllers/auth-controller");

// All routes are related to authentication and authorisation

router.post("/register", registerUser);

router.post("/login", loginUser);









module.exports = router;